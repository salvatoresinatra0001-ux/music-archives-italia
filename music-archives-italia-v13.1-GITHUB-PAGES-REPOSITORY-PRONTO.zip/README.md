# Music Archives Italia — GitHub Pages monorepository

This is a **deployment-ready source package**, not a deployed website or a created GitHub repository.

## Structure

- `index.html`: central entry portal
- `mylene-farmer-italia/`: Mylène Farmer v13.1
- `assemblage23-italia/`: Assemblage 23 v13.1
- `mesh-italia/`: MESH v13.1
- `sandra-music-italia/`: Sandra v13.1
- `thebirthdaymassacre-italia/`: The Birthday Massacre v13.1
- `ville-valo-him-heartagram-italia/`: Ville Valo / HIM / VV v13.1
- `.nojekyll`: disable Jekyll processing for static files

## How to deploy

1. Create a repository (proposed name `music-archives-italia`) under your GitHub account.
2. Upload these **extracted files and folders** to the **root** of `main` (do not upload the ZIP alone).
3. Configure **Settings > Pages > Build and deployment > Deploy from a branch > main / (root)**. Save.
4. The URLs will have this pattern only **after successful deployment**: `https://<username>.github.io/<repo>/<artist-folder>/`.
5. Review site privacy, rights clearance and metadata BEFORE public publication.

IMPORTANT: These artist sites include `robots` meta tags such as `noindex` from prepublication editions. Do not remove these blindly; they are maintained from the original versions and prevent intentional indexing while quality checks remain incomplete. GitHub Pages does NOT make the content private, even if your repository is private.

GitHub Pages on GitHub Free requires a PUBLIC repository. Using a private source repository requires an eligible paid plan; the generated Pages website is still public. A single repository exposes ONE Pages site with six paths, **not six independent Pages instances**.

Source: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
