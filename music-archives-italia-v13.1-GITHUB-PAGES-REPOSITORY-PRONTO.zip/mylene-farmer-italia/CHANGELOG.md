# Changelog

## 13.1.0 — 2026-10-15
- Ricostruzione editoriale e visuale in italiano con sei temi differenti.
- 13 pagine discografiche individuali per Mylène Farmer.
- 1 approfondimenti di edizioni con tracklist pubblicamente verificata.
- Nuova navigazione responsive, ricerca locale, player Spotify ufficiale a caricamento volontario.
- Collegamenti a piattaforme esterne, fonti primarie, policy di utilizzo immagine, informativa tecnica preliminare.
- Conservazione della 10.1 in allegato storico non modificato.
- Stati di verifica dichiarati esplicitamente; eliminata la moltiplicazione di pagine di riempimento.
