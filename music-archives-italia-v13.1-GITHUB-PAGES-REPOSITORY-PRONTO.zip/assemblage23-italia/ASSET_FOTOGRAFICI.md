# Fotografie e artwork

Non sono state scaricate fotografie promozionali, copertine, logotipi ufficiali o simboli proprietari, perché la mera reperibilità pubblica non equivale a licenza di ripubblicazione.

Per pubblicare nuove immagini:
- verificare autore, titolare e licenza di riutilizzo;
- conservare documentazione e crediti;
- verificare i limiti di immagini promozionali, copertine e loghi;
- inserire file e relativa attribuzione nel progetto solo quando l'autorizzazione è chiara.

Il player Spotify usa l'integrazione dell'operatore, a caricamento volontario.
