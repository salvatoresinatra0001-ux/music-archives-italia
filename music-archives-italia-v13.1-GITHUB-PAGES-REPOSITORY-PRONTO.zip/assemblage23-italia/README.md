# Assemblage 23 — Archivio italiano v13.1.0

Edizione locale originale, in italiano, non affiliata all'artista.

## Come si apre
1. Estrarre lo ZIP in una cartella.
2. Aprire `index.html` nel browser.
3. Il player Spotify e i collegamenti esterni richiedono una connessione Internet; il player si carica solo dopo il clic.

## Contenuti
- 10 schede di pubblicazioni con fonte, anno e categoria.
- 2 approfondimenti con sequenza documentata e dettagli formati.
- Indice singoli, percorso, metodologia, fonti, contatti, privacy, ascolto.
- `catalogo.json` con dati strutturati.

## Importante
- Non incorpora fotografie promozionali o copertine senza licenza.
- I grafismi sono astratti e originali; non rappresentano opere d'arte ufficiali.
- `robots=noindex,nofollow` è intenzionale: è un'edizione locale non ancora pubblicabile senza revisione finale.
- Non esistono contatti redazionali configurati né analytics.
- Non confondere i titoli storici con tutte le singole edizioni di stampa.

## Fonte primaria principale
https://www.assemblage23.com/

Revisione al 15 ottobre 2026.
